from turtle import*
speed(10)
color("green")
bgcolor("black")
b = 200
while b > 0:
  left(b)
  forward(b * 2)
  b = b - 1
